# Evidence for this issue only

Baseline: `d22cf39c195296a69ded2763cbe22010c8273865`; Windows / Python 3.13.

A bounded mission has full_task containing a synthetic latest continuation (checkpoint B is complete; do not repeat A), followed by its old objective. _run_bounded_planning passes only the old objective to draft_plan. The integration spy sees the continuation omitted. No model call is required to demonstrate the lost input.

These are recorded audit observations, not a new check of today's moving main branch. Failing synthetic assertions reproduce the defect on this baseline. No real research task or model call is used.
