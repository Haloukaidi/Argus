# Reproduction instructions

Baseline: `lbx154/Argus` at `d22cf39c195296a69ded2763cbe22010c8273865`, Windows / Python 3.13.
This attachment contains only this issue's reproductions and selected evidence.
Use an isolated source checkout and an activated development virtual environment with Argus installed editable and pytest available. Do not run against a locally patched installation.

In PowerShell, from the repository root, replace the attachment path below:

```powershell
$argusProblemDir = 'C:\path\to\extracted-attachment'
$env:ARGUS_AUDIT_SOURCE = (Get-Location).Path
$env:PYTHONPATH = (Get-Location).Path
python -c "import argus_skill; print(argus_skill.__file__)"
python -m pytest -q "$argusProblemDir\repro\test_resume_stop_regression.py"
```

Confirm the import path is the intended source checkout. Use a separate shell for this reproduction so these temporary environment settings do not affect another session. The process and pipe probes require Windows and clean up their own synthetic children. Expected baseline observations are in `evidence/README.md` and the JSON files. Private helper signatures may change on future upstream commits; an API mismatch is not itself proof of this bug. The split files retain the original audit test names; only tests or entry-point cases for this issue are selected.
