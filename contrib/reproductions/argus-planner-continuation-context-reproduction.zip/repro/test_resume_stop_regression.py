"""Continuation context and authoritative operator-stop regression coverage."""
from types import SimpleNamespace

import pytest

from argus_skill.adapters.agent_cli_backend._result import UsageAccumulator, translate_result
from argus_skill.agent_cli._run_exec import _StreamState
from argus_skill.agent_cli.agent_cli_runner import AgentCliRunner, RunnerOptions
from argus_skill.apps._runtime_execute import SkillLoopExecuteMixin
from argus_skill.provider_integrations.authorization_retry import _unauthorized_cause










def test_bounded_planner_receives_latest_continuation_before_old_objective(monkeypatch, tmp_path):
    captured = []
    def draft(backend, objective, **kwargs):
        captured.append(objective)
        return SimpleNamespace(steps=[], error="stub: advisory unavailable")
    monkeypatch.setattr("argus_skill.manager.plan_mode.draft_plan", draft)
    monkeypatch.setattr("argus_skill.roles.prompts.resolve_role_prompt", lambda request: SimpleNamespace(role_banner="Planner"))
    runner = SkillLoopExecuteMixin()
    runner._args = SimpleNamespace(plan_model="gpt-6-astra")
    runner._backend = object()
    full_task = "Latest continuation: diagnostic completed at checkpoint B; do not repeat A.\n---\n## Live objective\nOld objective: investigate checkpoint A."
    state = SimpleNamespace(workdir=tmp_path, config=SimpleNamespace(workflow_mode="staged"), full_task=full_task, planner_task=full_task)
    events=[]
    runner._run_bounded_planning(state, sink=SimpleNamespace(handle_event=events.append),
                                objective="Old objective: investigate checkpoint A.",
                                original_objective="Immutable research objective", preplanned=False, mission_id="mission")
    assert captured == [full_task]
    assert state.full_task == full_task
    assert events[-1]["type"] == "life.planner.error"




