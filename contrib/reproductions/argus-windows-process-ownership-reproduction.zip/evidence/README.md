# Evidence for this issue only

Baseline: `d22cf39c195296a69ded2763cbe22010c8273865`; Windows / Python 3.13.

A fake provider is launched through the actual _spawn_turn_process path and starts a sleep child. Calling the runner stop method exits the parent, but a previously acquired handle reports the child still active. The audit terminated only that held child and verified exit. The current natural-exit cleanup also returns immediately on Windows.

These are recorded audit observations, not a new check of today's moving main branch. Failing synthetic assertions reproduce the defect on this baseline. No real research task or model call is used.
