"""Bounded independent checks of existing fixes; no project or model execution."""
import ctypes,json,os,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
BASE=Path(__file__).resolve().parent
sys.path.insert(0, str(Path(os.environ.get("ARGUS_AUDIT_SOURCE", Path.cwd())).resolve()))
from argus_skill.adapters.agent_cli_backend._result import translate_result,UsageAccumulator
from argus_skill.agent_cli.models import AgentRunResult
from argus_skill.agent_cli.agent_cli_runner import AgentCliRunner, RunnerOptions
from argus_skill.provider_integrations.authorization_retry import _unauthorized_cause
out=[]
if os.name != 'nt':
    raise SystemExit('This process ownership probe requires Windows.')
if os.name=='nt':
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p
    kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
    kernel.TerminateProcess.argtypes=[ctypes.c_void_p,ctypes.c_uint]
    kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
    kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    child_code='import time;time.sleep(30)'
    parent_code='import subprocess,sys,time; child=subprocess.Popen([sys.executable,"-c",'+repr(child_code)+'],creationflags=subprocess.CREATE_NO_WINDOW); print(child.pid,flush=True); time.sleep(30)'
    runner=AgentCliRunner(agent_bin=sys.executable,backend='codex')
    runner._build_command=lambda **kwargs: [sys.executable,'-u','-c',parent_code]
    command,parent,failure,prompt_path=runner._spawn_turn_process(prompt='fixture',resume_thread_id=None,options=RunnerOptions(working_dir=str(BASE)))
    assert failure is None
    handle=None
    try:
        child_pid=int(parent.stdout.readline());handle=kernel.OpenProcess(0x100000|0x1000|0x1,False,child_pid);assert handle
        runner._terminate_process(parent)
        exit_code=ctypes.c_ulong();assert kernel.GetExitCodeProcess(handle,ctypes.byref(exit_code))
        surviving=exit_code.value==259
        out.append({'case':'windows_owned_child_cleanup','parent_pid':parent.pid,'child_pid':child_pid,'parent_exited':parent.poll() is not None,'child_survived_runner_stop':surviving})
    finally:
        if parent.poll() is None:parent.terminate();parent.wait(timeout=3)
        if handle:
            kernel.TerminateProcess(handle,0);kernel.WaitForSingleObject(handle,3000)
            code=ctypes.c_ulong();kernel.GetExitCodeProcess(handle,ctypes.byref(code));out[-1]['test_child_cleanup_verified']=code.value!=259;kernel.CloseHandle(handle)
(BASE/'normal-spawn-residual-results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
